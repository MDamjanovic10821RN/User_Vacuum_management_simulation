package raf.rs.domaci3.model;

import jakarta.persistence.*;
import lombok.Data;

import java.util.Date;

@Data
@Entity
@Table(name = "ERRORS")
public class ErrorMessage {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(nullable = false)
    private Long vacuumId;
    @Column(nullable = false)
    private Long userId;
    @Column(nullable = false)
    private Date date;
    @Column(nullable = false)
    private String operation;
    @Column(nullable = false)
    private String message;

    public ErrorMessage(Long vacuumId, Long userId, Date date, String operation, String message) {
        this.vacuumId = vacuumId;
        this.userId = userId;
        this.date = date;
        this.operation = operation;
        this.message = message;
    }

    public ErrorMessage() {

    }
}
