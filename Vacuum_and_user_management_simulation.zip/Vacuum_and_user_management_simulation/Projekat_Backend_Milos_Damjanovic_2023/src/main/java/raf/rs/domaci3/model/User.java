package raf.rs.domaci3.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

@Data
@Entity
@Builder
@AllArgsConstructor
@RequiredArgsConstructor
@Table(name = "USER")
public class User implements UserDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String firstName;

    @Column(nullable = false)
    private String lastName;

    @Column(unique = true)
    private String email;

    @Column(nullable = false)
    private String password;

    private Boolean can_create_users;
    private Boolean can_read_users;
    private Boolean can_update_users;
    private Boolean can_delete_users;

    private Boolean can_search_vacuum;
    private Boolean can_start_vacuum;
    private Boolean can_stop_vacuum;
    private Boolean can_discharge_vacuum;
    private Boolean can_add_vacuum;
    private Boolean can_remove_vacuums;


    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        List ret = new ArrayList();

        if(can_create_users)
            ret.add("can_create_users");
        if(can_read_users)
            ret.add("can_read_users");
        if(can_update_users)
            ret.add("can_update_users");
        if(can_delete_users)
            ret.add("can_delete_users");

        if(can_search_vacuum)
            ret.add("can_search_vacuum");
        if(can_start_vacuum)
            ret.add("can_start_vacuum");
        if(can_stop_vacuum)
            ret.add("can_stop_vacuum");
        if(can_discharge_vacuum)
            ret.add("can_discharge_vacuum");
        if(can_add_vacuum)
            ret.add("can_add_vacuum");
        if(can_remove_vacuums)
            ret.add("can_remove_vacuums");

        return new ArrayList<>();
    }

    @Override
    public String getUsername() {
        return email;
    }

    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    @Override
    public boolean isEnabled() {
        return true;
    }
}