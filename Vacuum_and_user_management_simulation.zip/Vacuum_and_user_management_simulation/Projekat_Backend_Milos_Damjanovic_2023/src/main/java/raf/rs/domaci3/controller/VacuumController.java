package raf.rs.domaci3.controller;

import jakarta.validation.Valid;
import org.springframework.boot.json.JsonParserFactory;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;
import raf.rs.domaci3.enums.VacStatus;
import raf.rs.domaci3.model.User;
import raf.rs.domaci3.model.Vacuum;
import raf.rs.domaci3.requests.SearchVacuumRequest;
import raf.rs.domaci3.service.UserService;
import raf.rs.domaci3.service.VacuumService;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/vacuums")
@CrossOrigin
public class VacuumController {

    private final VacuumService vacuumService;
    private final UserService userService;

    public VacuumController(VacuumService vacuumService, UserService userService) {
        this.vacuumService = vacuumService;
        this.userService = userService;

    }
    //------------------------------------------------------------------------------------------------------------------

    @GetMapping(value = "/all", produces = MediaType.APPLICATION_JSON_VALUE) //FOR TESTING PURPOSES
    public List<Vacuum> getAllVacuums(){
        return vacuumService.findAll();
    }

    @GetMapping(value = "/byUser", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> getVacuumsForUser(){

        User user = userService.findUserByEmail(((User)SecurityContextHolder.getContext().getAuthentication().getPrincipal()).getEmail()).get();
        Long id = user.getId();
        return ResponseEntity.ok(vacuumService.findByUser(id));
    }

    @GetMapping(value = "/get/{id}", produces = MediaType.APPLICATION_JSON_VALUE) //TODO: NOT TESTED
    public ResponseEntity<?> getbyID(@PathVariable("id") Long id){
        Optional<Vacuum> vacuum = (vacuumService.findById(id));
        if(vacuum.isPresent()) {
            return ResponseEntity.ok(vacuum.get());
        }
        else return ResponseEntity.notFound().build();
    }

    @PostMapping(value = "/new", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> createVacuum(@RequestBody String vacuumName){

        if(((User)SecurityContextHolder.getContext().getAuthentication().getPrincipal()).getCan_add_vacuum()) {
            User user = userService.findUserByEmail(((User) SecurityContextHolder.getContext().getAuthentication().getPrincipal()).getEmail()).get();
            //System.out.println("[DEBUG]--------------USER EMAIL: "+ ((User)SecurityContextHolder.getContext().getAuthentication().getPrincipal()).getEmail() );

            Vacuum vacuum = new Vacuum();

            vacuum.setName(vacuumName);
            vacuum.setStatus(VacStatus.STOPPED);
            vacuum.setUser(user);
            vacuum.setActive(true);
            vacuum.setDate(LocalDate.now());

            return ResponseEntity.ok(vacuumService.save(vacuum));
        }else{
            return new ResponseEntity<String>("You do not have permission to perform this action", HttpStatus.FORBIDDEN);
        }
    }

    @DeleteMapping(value = "/delete/{id}")
    public ResponseEntity<?> deleteVacuum(@PathVariable("id") Long id){

        if(((User)SecurityContextHolder.getContext().getAuthentication().getPrincipal()).getCan_add_vacuum()) {
            Optional<Vacuum> vacuum = (vacuumService.findById(id));

            if (vacuum.isPresent()) {
                vacuumService.deleteById(id);
                return ResponseEntity.ok().build();
            } else return ResponseEntity.notFound().build();
        }else{
            return new ResponseEntity<String>("You do not have permission to perform this action", HttpStatus.FORBIDDEN);
        }
    }

    @PutMapping(value = "/search", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> searchMachine(@RequestBody SearchVacuumRequest searchVacuum){

        if(((User)SecurityContextHolder.getContext().getAuthentication().getPrincipal()).getCan_search_vacuum()) {
            User user = userService.findUserByEmail(((User)SecurityContextHolder.getContext().getAuthentication().getPrincipal()).getEmail()).get();

            String email = user.getEmail();
            String name = searchVacuum.getName();
            List<VacStatus> status = searchVacuum.getStatus();
            LocalDate dateFrom = searchVacuum.getDateFrom();
            LocalDate dateTo = searchVacuum.getDateTo();

            return new ResponseEntity<>(vacuumService.search(email,status,name,dateFrom,dateTo), HttpStatus.OK);

        }else{
            return new ResponseEntity<String>("You do not have permission to perform this action", HttpStatus.FORBIDDEN);
        }
    }
    //------------------------------------------------------------------------------------------------------------------

    @GetMapping(value = "/start/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> Start(@PathVariable("id") Long id){

        if(((User)SecurityContextHolder.getContext().getAuthentication().getPrincipal()).getCan_start_vacuum()) {
            //System.out.println("[DEBUG]----------------------STARTING");
            return new ResponseEntity<>(vacuumService.start(id), HttpStatus.OK);
        }else{
            return new ResponseEntity<String>("You do not have permission to perform this action", HttpStatus.FORBIDDEN);
        }
    }

    @GetMapping(value = "/stop/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> Stop(@PathVariable("id") Long id){

        if(((User)SecurityContextHolder.getContext().getAuthentication().getPrincipal()).getCan_stop_vacuum()) {
            //System.out.println("[DEBUG]----------------------STOPPING");
            return new ResponseEntity<>(vacuumService.stop(id), HttpStatus.OK);
        }else{
            return new ResponseEntity<String>("You do not have permission to perform this action", HttpStatus.FORBIDDEN);
        }
    }

    @GetMapping(value = "/discharge/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> discharge(@PathVariable("id") Long id){

        if(((User)SecurityContextHolder.getContext().getAuthentication().getPrincipal()).getCan_discharge_vacuum()) {
            //System.out.println("[DEBUG]----------------------DISCHARGING");
            return new ResponseEntity<>(vacuumService.discharge(id), HttpStatus.OK);
        }else{
            return new ResponseEntity<String>("You do not have permission to perform this action", HttpStatus.FORBIDDEN);
        }
    }
    //------------------------------------------------------------------------------------------------------------------

    @GetMapping(value = "/scheduledStart/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> ScheduledStart(@PathVariable("id") Long id, @RequestParam @DateTimeFormat(pattern = "dd.MM.yyyy HH:mm") Date date){

        if(((User)SecurityContextHolder.getContext().getAuthentication().getPrincipal()).getCan_start_vacuum()) {
            User user = userService.findUserByEmail(((User)SecurityContextHolder.getContext().getAuthentication().getPrincipal()).getEmail()).get();
            Long userId = user.getId();

            return new ResponseEntity<>(vacuumService.scheduledStart(id,userId,date), HttpStatus.OK);

        }else{
            return new ResponseEntity<String>("You do not have permission to perform this action", HttpStatus.FORBIDDEN);
        }

    }

    @GetMapping(value = "/scheduledStop/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> ScheduledStop(@PathVariable("id") Long id, @RequestParam @DateTimeFormat(pattern = "dd.MM.yyyy HH:mm") Date date){

        if(((User)SecurityContextHolder.getContext().getAuthentication().getPrincipal()).getCan_stop_vacuum()) {
            User user = userService.findUserByEmail(((User)SecurityContextHolder.getContext().getAuthentication().getPrincipal()).getEmail()).get();
            Long userId = user.getId();

            return new ResponseEntity<>(vacuumService.scheduledStop(id,userId,date), HttpStatus.OK);

        }else{
            return new ResponseEntity<String>("You do not have permission to perform this action", HttpStatus.FORBIDDEN);
        }

    }

    @GetMapping(value = "/scheduledDischarge/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> ScheduledDischarge(@PathVariable("id") Long id, @RequestParam @DateTimeFormat(pattern = "dd.MM.yyyy HH:mm") Date date){

        if(((User)SecurityContextHolder.getContext().getAuthentication().getPrincipal()).getCan_discharge_vacuum()) {
            User user = userService.findUserByEmail(((User)SecurityContextHolder.getContext().getAuthentication().getPrincipal()).getEmail()).get();
            Long userId = user.getId();

            return new ResponseEntity<>(vacuumService.scheduledDischarge(id,userId,date), HttpStatus.OK);

        }else{
            return new ResponseEntity<String>("You do not have permission to perform this action", HttpStatus.FORBIDDEN);
        }
    }
}
