package raf.rs.domaci3.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import raf.rs.domaci3.model.User;
import raf.rs.domaci3.repository.UserRepository;


import java.util.List;
import java.util.Optional;

@Service
public class UserService implements IService<User, Long>{

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    @Autowired
    public UserService(UserRepository userRepository, PasswordEncoder passwordEncoder){ this.userRepository = userRepository; this.passwordEncoder = passwordEncoder; }

    @Override
    public <S extends User> S save(S var1) {
        var1.setPassword(passwordEncoder.encode(var1.getPassword()));
        return userRepository.save(var1);
    }

    public Optional<User> findUserByEmail(String email) {
        return userRepository.findOptionalUserByEmail(email);
    }


    @Override
    public Optional<User> findById(Long var1) { return userRepository.findById(var1); }

    @Override
    public List<User> findAll() { return (List<User>) userRepository.findAll(); }

    @Override
    public void deleteById(Long var1) { userRepository.deleteById(var1);}

}