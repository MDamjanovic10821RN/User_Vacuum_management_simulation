package raf.rs.domaci3.controller;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import raf.rs.domaci3.model.ErrorMessage;
import raf.rs.domaci3.model.User;
import raf.rs.domaci3.service.ErrorMessageService;
import raf.rs.domaci3.service.UserService;

import java.util.List;

@RestController
@CrossOrigin
@RequestMapping("/errors")
public class ErrorMessageController {

    private final ErrorMessageService errorMessageService;
    private final UserService userService;

    public ErrorMessageController(ErrorMessageService errorMessageService, UserService userService) {
        this.errorMessageService = errorMessageService;
        this.userService = userService;
    }

    @GetMapping(value = "/get")
    public List<ErrorMessage> getAllErrors(){
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        User user = userService.findUserByEmail(authentication.getName()).get();

        return errorMessageService.findAllByUserId(user.getId());
    }
}
