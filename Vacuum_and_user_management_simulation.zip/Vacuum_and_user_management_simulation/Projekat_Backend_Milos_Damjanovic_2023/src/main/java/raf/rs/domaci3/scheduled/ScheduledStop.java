package raf.rs.domaci3.scheduled;

import raf.rs.domaci3.enums.VacStatus;
import raf.rs.domaci3.model.ErrorMessage;
import raf.rs.domaci3.model.Vacuum;
import raf.rs.domaci3.repository.ErrorMessageRepository;
import raf.rs.domaci3.repository.VacuumRepository;
import raf.rs.domaci3.service.AsyncComponent;

import java.util.Date;
import java.util.Optional;

public class ScheduledStop implements Runnable{
    private VacuumRepository vacuumRepository;
    private AsyncComponent asyncComponent;
    private ErrorMessageRepository errorMessageRepository;

    private Long vacId;
    private Long userId;

    public ScheduledStop(VacuumRepository vacuumRepository, Long vacId, Long userId, AsyncComponent asyncComponent, ErrorMessageRepository errorMessageRepository) {
        this.vacuumRepository = vacuumRepository;
        this.vacId = vacId;
        this.userId = userId;
        this.asyncComponent = asyncComponent;
        this.errorMessageRepository = errorMessageRepository;
    }


    @Override
    public void run() {
        Optional<Vacuum> vacuum = vacuumRepository.findById(this.vacId);
        if (vacuum.isPresent()){

            if(!vacuum.get().isActive()){
                ErrorMessage em = new ErrorMessage(this.vacId, this.userId, new Date(),"STOP","Vacuum is not active in the system");
                errorMessageRepository.save(em);
                return;
            }
            if(vacuum.get().isProcessing()){
                ErrorMessage em = new ErrorMessage(this.vacId, this.userId, new Date(),"STOP","Vacuum is currently in another process");
                errorMessageRepository.save(em);
                return;
            }
            if(!vacuum.get().getStatus().equals(VacStatus.RUNNING)){
                ErrorMessage em = new ErrorMessage(this.vacId, this.userId, new Date(),"STOP","Vacuum must be RUNNING in order to stop");
                errorMessageRepository.save(em);
                return;
            }

            vacuum.get().setProcessing(true);
            vacuumRepository.save(vacuum.get());
            asyncComponent.startVacuum(vacuum.get());

        }else{

            ErrorMessage em = new ErrorMessage(this.vacId, this.userId, new Date(),"STOP","Vacuum not found");
            errorMessageRepository.save(em);

        }
    }
}
