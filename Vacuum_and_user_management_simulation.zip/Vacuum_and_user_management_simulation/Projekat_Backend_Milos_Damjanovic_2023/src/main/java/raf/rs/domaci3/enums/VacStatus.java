package raf.rs.domaci3.enums;

public enum VacStatus {
    ON,
    OFF,
    DISCHARGING,
    STOPPED,
    RUNNING
}
