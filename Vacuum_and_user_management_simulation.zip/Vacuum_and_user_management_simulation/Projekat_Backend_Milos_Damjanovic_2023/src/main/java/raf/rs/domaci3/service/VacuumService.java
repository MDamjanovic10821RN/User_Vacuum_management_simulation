package raf.rs.domaci3.service;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.TaskScheduler;
import org.springframework.stereotype.Service;
import raf.rs.domaci3.enums.VacStatus;
import raf.rs.domaci3.model.User;
import raf.rs.domaci3.model.Vacuum;
import raf.rs.domaci3.repository.ErrorMessageRepository;
import raf.rs.domaci3.repository.VacuumRepository;
import raf.rs.domaci3.scheduled.ScheduledDischarge;
import raf.rs.domaci3.scheduled.ScheduledStart;
import raf.rs.domaci3.scheduled.ScheduledStop;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@Service
public class VacuumService implements IService<Vacuum, Long>{

    private final VacuumRepository vacuumRepository;
    private final AsyncComponent asyncComponent;
    private final TaskScheduler taskScheduler;
    private final ErrorMessageRepository errorMessageRepository;

    public VacuumService(VacuumRepository vacuumRepository, AsyncComponent asyncComponent, ErrorMessageRepository errorMessageRepository, TaskScheduler taskScheduler){
        this.vacuumRepository = vacuumRepository;
        this.asyncComponent = asyncComponent;
        this.taskScheduler = taskScheduler;
        this.errorMessageRepository = errorMessageRepository;
    }

    @Override
    public <S extends Vacuum> S save(S var1) {
        return this.vacuumRepository.save(var1);
    }

    @Override
    public Optional<Vacuum> findById(Long var1) { return this.vacuumRepository.findById(var1); }

    @Override
    public List<Vacuum> findAll() { return this.vacuumRepository.findAll(); }

    public List<Vacuum> findByUser(Long id) { return this.vacuumRepository.findVacuumsByUserId(id); }

    public List<Vacuum> search (String email, List<VacStatus> status, String name, LocalDate dateFrom, LocalDate dateTo){
        return this.vacuumRepository.searchVacuums(email,status,name,dateFrom,dateTo);
    }

    @Override
    public void deleteById(Long var1) {
        Optional<Vacuum> vacuum = this.vacuumRepository.findById(var1);
        Vacuum vacToDelete;
        if(vacuum.isPresent()){
            vacToDelete = vacuum.get();
            vacToDelete.setActive(false);
            this.vacuumRepository.save(vacToDelete);
        }
    }
    //--------------------------------------------------------------------------------------------------------------------

    public ResponseEntity<?> start(Long id){
        System.out.println("[DEBUG]----------------------IN SERVICE");
        Optional<Vacuum> vacuum = vacuumRepository.findById(id);

        if(vacuum.isPresent()){

            if(!vacuum.get().getStatus().equals(VacStatus.STOPPED)){
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Vacuum ("+ id +") must be \"STOPPED\"");
            }
            if(vacuum.get().isProcessing()){
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Vacuum ("+ id +") is currently processing");
            }

            Vacuum vac = vacuum.get();
            vac.setProcessing(true);
            vacuumRepository.save(vac);
            asyncComponent.startVacuum(vac);
            return ResponseEntity.ok(vac);

        }

        return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Vacuum not found");
    }

    public ResponseEntity<?> stop(Long id){

        Optional<Vacuum> vacuum = vacuumRepository.findById(id);

        if(vacuum.isPresent()) {

            if(!vacuum.get().getStatus().equals(VacStatus.RUNNING)){
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Vacuum ("+ id +") must be \"RUNNING\"");
            }
            if(vacuum.get().isProcessing()){
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Vacuum ("+ id +") is currently processing");
            }

            Vacuum vac = vacuum.get();
            vac.setProcessing(true);
            vacuumRepository.save(vac);
            asyncComponent.stopVacuum(vac);
            return ResponseEntity.ok(vac);
        }

        return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Vacuum not found");
    }

    public ResponseEntity<?> discharge(Long id){

        Optional<Vacuum> vacuum = vacuumRepository.findById(id);

        if(vacuum.isPresent()) {

            if(!vacuum.get().getStatus().equals(VacStatus.STOPPED)){
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Vacuum ("+ id +") must be \"STOPPED\"");
            }
            if(vacuum.get().isProcessing()){
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Vacuum ("+ id +") is currently processing");
            }

            Vacuum vac = vacuum.get();
            vac.setProcessing(true);
            vacuumRepository.save(vac);
            asyncComponent.dischargeVacuum(vac);
            return ResponseEntity.ok(vac);
        }

        return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Vacuum not found");
    }
    //------------------------------------------------------------------------------------------------------------------

    public ResponseEntity<?> scheduledStart(Long vacuumId, Long userId, Date date){
        taskScheduler.schedule(new ScheduledStart(vacuumRepository, vacuumId, userId, asyncComponent, errorMessageRepository), date);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    public ResponseEntity<?> scheduledStop(Long vacuumId, Long userId, Date date){
        taskScheduler.schedule(new ScheduledStop(vacuumRepository, vacuumId, userId, asyncComponent, errorMessageRepository), date);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    public ResponseEntity<?> scheduledDischarge(Long vacuumId, Long userId, Date date){
        taskScheduler.schedule(new ScheduledDischarge(vacuumRepository, vacuumId, userId, asyncComponent, errorMessageRepository), date);
        return new ResponseEntity<>(HttpStatus.OK);
    }

}