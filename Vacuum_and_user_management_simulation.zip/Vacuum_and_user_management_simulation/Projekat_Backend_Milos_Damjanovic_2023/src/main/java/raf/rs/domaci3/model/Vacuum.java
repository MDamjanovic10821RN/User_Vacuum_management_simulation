package raf.rs.domaci3.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import raf.rs.domaci3.enums.VacStatus;

import java.time.LocalDate;

@Data
@Entity
@Builder
@AllArgsConstructor
@RequiredArgsConstructor
@Table(name = "VACUUM")
public class Vacuum {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String name;

    @Enumerated(EnumType.STRING)
    @Column(name="status",nullable = false)
    private VacStatus status;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "addedBy", nullable = false)
    private User user;

    @Column(name="active",nullable = false)
    private boolean active;

    @Column(nullable = false)
    private LocalDate date;

    private boolean processing; //da se vidi da li se pali/gasi... da li je u nekom procesu

}
