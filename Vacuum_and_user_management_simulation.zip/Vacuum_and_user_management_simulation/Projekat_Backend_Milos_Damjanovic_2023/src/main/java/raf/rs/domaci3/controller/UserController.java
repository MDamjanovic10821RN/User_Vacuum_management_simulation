package raf.rs.domaci3.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;
import raf.rs.domaci3.model.User;
import org.springframework.http.ResponseEntity;
import raf.rs.domaci3.service.UserService;


import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/users")
@CrossOrigin
public class UserController {

    private final UserService userService;

    @Autowired
    public UserController(UserService userService){ this.userService = userService; }

    @GetMapping(path = "/all", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> getAllUsers() {

        if(((User)SecurityContextHolder.getContext().getAuthentication().getPrincipal()).getCan_read_users()){
            return ResponseEntity.ok(userService.findAll());
        }else{
            return new ResponseEntity<String>("You do not have permission to perform this action", HttpStatus.FORBIDDEN);
        }

    }

    @GetMapping(value = "/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> getUserById(@PathVariable("id") Long id){

        Optional<User> optionalUser = userService.findById(id);
        if(optionalUser.isPresent()) {
            return ResponseEntity.ok(optionalUser.get());
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping(value = "/new", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> createUser(@RequestBody User user){

        if(((User)SecurityContextHolder.getContext().getAuthentication().getPrincipal()).getCan_create_users()){
            return ResponseEntity.ok(userService.save(user));
        }else{
            return new ResponseEntity<String>("You do not have permission to perform this action", HttpStatus.FORBIDDEN);
        }
    }

    @PutMapping(value = "/update", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> updateTeacher(@RequestBody User user){

        if(((User)SecurityContextHolder.getContext().getAuthentication().getPrincipal()).getCan_update_users()){
            return ResponseEntity.ok(userService.save(user));
        }else{
            return new ResponseEntity<String>("You do not have permission to perform this action", HttpStatus.FORBIDDEN);
        }
    }

    @DeleteMapping(value = "/delete/{id}")
    public ResponseEntity<?> deleteTeacher(@PathVariable("id") Long id){

        if(((User)SecurityContextHolder.getContext().getAuthentication().getPrincipal()).getCan_delete_users()){
            userService.deleteById(id);
            return ResponseEntity.ok().build();
        }else{
            return new ResponseEntity<String>("You do not have permission to perform this action", HttpStatus.FORBIDDEN);
        }
    }

}
