package raf.rs.domaci3.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import raf.rs.domaci3.enums.VacStatus;
import raf.rs.domaci3.model.User;
import raf.rs.domaci3.model.Vacuum;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface VacuumRepository extends JpaRepository<Vacuum, Long> {

    @Query("select v from Vacuum v where" +
            " ((v.name like %:name% or :name is null) and" +
            " ((v.date between :dateFrom and :dateTo) or (:dateFrom is null or :dateTo is null)) and" +
            " (v.status in (:status) or :status is null)) and v.user.email = :email")
    List<Vacuum> searchVacuums(String email, List<VacStatus> status, String name, LocalDate dateFrom, LocalDate dateTo);

    @Query("select v from Vacuum v where :id = v.user.id")
    List<Vacuum> findVacuumsByUserId(@Param("id")Long id);
}
