package raf.rs.domaci3.OAuth2;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import raf.rs.domaci3.model.User;
import raf.rs.domaci3.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class AuthenticationService {
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtService jwtService;
    private final AuthenticationManager authenticationManager;

    public AuthenticationResponse register(RegisterRequest request) {
        var user = User.builder()
                .email(request.getUsername())
                .password(passwordEncoder.encode(request.getPassword()))
                .firstName(request.getFirstName())
                .lastName(request.getLastName())
                .can_create_users(request.getCan_create_users())
                .can_read_users(request.getCan_read_users())
                .can_update_users(request.getCan_update_users())
                .can_delete_users(request.getCan_delete_users())
                .can_search_vacuum(request.getCan_search_vacuum())
                .can_start_vacuum(request.getCan_start_vacuum())
                .can_stop_vacuum(request.getCan_stop_vacuum())
                .can_discharge_vacuum(request.getCan_discharge_vacuum())
                .can_add_vacuum(request.getCan_add_vacuum())
                .can_remove_vacuums(request.getCan_remove_vacuums())
                .build();

        userRepository.save(user);
        var jwtToken = jwtService.generateToken(user);

        return AuthenticationResponse.builder()
                .token(jwtToken)
                .build();
    }

    public AuthenticationResponse authenticate(AuthenticationRequest request) {

        var am = authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(request.getUsername(), request.getPassword()));

        var user = userRepository.findUserByEmail(request.getUsername());


        Map<String, Object> hm = new HashMap<>(); //DODAVANJE SVIH PERMISIJA U TOKEN
        hm.put("c",user.getCan_create_users());
        hm.put("r",user.getCan_read_users());
        hm.put("u",user.getCan_update_users());
        hm.put("d",user.getCan_delete_users());
        hm.put("search",user.getCan_search_vacuum());
        hm.put("start",user.getCan_start_vacuum());
        hm.put("stop",user.getCan_stop_vacuum());
        hm.put("discharge",user.getCan_discharge_vacuum());
        hm.put("add",user.getCan_add_vacuum());
        hm.put("remove",user.getCan_remove_vacuums());

        var jwtToken = jwtService.generateToken(hm, user);
        return AuthenticationResponse.builder()
                .token(jwtToken)
                .build();

    }
}
