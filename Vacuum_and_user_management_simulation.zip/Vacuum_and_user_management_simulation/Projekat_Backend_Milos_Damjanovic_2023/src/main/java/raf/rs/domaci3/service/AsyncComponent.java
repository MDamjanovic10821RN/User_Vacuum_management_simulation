package raf.rs.domaci3.service;

import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import raf.rs.domaci3.enums.VacStatus;
import raf.rs.domaci3.model.Vacuum;
import raf.rs.domaci3.repository.VacuumRepository;

@Component
public class AsyncComponent {

    private final VacuumRepository vacuumRepository;

    public AsyncComponent(VacuumRepository vacuumRepository) {
        this.vacuumRepository = vacuumRepository;
    }

    @Async
    public void startVacuum(Vacuum vacuum){

        long delay = 15000;

        try {
            Thread.sleep(delay);
        }
        catch (Exception e){
            System.out.println("[Start Error]");
        }

        vacuum.setStatus(VacStatus.RUNNING); //TODO: OVDE SE MENJA STATUS -> MIGHT BE A PROBLEM (dodatno sam dodao status "RUNNING"... nisam kreirao inicijalno taj enum)
        vacuum.setProcessing(false); //zavrsio se proces startovanja -> is no longer processing
        vacuumRepository.save(vacuum);
    }

    @Async
    public void stopVacuum(Vacuum vacuum){

        long delay = 15000;

        try {
            Thread.sleep(delay);
        }
        catch (Exception e){
            System.out.println("[Stop Error]");
        }

        vacuum.setStatus(VacStatus.STOPPED);
        vacuum.setProcessing(false);
        vacuumRepository.save(vacuum);
    }

    @Async
    public void dischargeVacuum(Vacuum vacuum){

        long delay = 15000;

        try {
            Thread.sleep(delay);
        }
        catch (Exception e){
            System.out.println("[Discharge (first half) Error]");
        }

        vacuum.setStatus(VacStatus.DISCHARGING); //"nakon protekle polovine"
        vacuumRepository.save(vacuum);

        try {
            Thread.sleep(delay);
        }
        catch (Exception e){
            System.out.println("[Discharge (second half) Error]");
        }

        vacuum.setStatus(VacStatus.STOPPED);
        vacuum.setProcessing(false);
        vacuumRepository.save(vacuum);
    }
}
