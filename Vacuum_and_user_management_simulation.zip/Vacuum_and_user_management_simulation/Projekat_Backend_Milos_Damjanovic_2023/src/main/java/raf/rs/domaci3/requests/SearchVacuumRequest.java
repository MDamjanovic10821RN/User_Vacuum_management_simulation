package raf.rs.domaci3.requests;

import lombok.Data;
import raf.rs.domaci3.enums.VacStatus;

import java.time.LocalDate;
import java.util.List;

@Data
public class SearchVacuumRequest {
    private String name;
    private List<VacStatus> status;
    private LocalDate dateFrom;
    private LocalDate dateTo;
}
