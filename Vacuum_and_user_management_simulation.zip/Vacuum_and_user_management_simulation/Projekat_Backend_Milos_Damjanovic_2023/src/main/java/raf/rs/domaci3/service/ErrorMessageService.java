package raf.rs.domaci3.service;

import org.springframework.stereotype.Service;
import raf.rs.domaci3.model.ErrorMessage;
import raf.rs.domaci3.repository.ErrorMessageRepository;

import java.util.List;

@Service
public class ErrorMessageService {

    private final ErrorMessageRepository errorMessageRepository;

    public ErrorMessageService(ErrorMessageRepository errorMessageRepository) {
        this.errorMessageRepository = errorMessageRepository;
    }

    public List<ErrorMessage> findAllByUserId(Long id){
        return this.errorMessageRepository.findAllByUserId(id);
    }
}
