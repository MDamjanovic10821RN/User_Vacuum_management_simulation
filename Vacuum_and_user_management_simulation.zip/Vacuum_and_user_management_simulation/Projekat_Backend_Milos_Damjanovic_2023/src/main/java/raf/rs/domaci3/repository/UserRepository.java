package raf.rs.domaci3.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import raf.rs.domaci3.model.User;

import java.util.Optional;


@Repository
public interface UserRepository extends CrudRepository<User, Long>{
    User findUserByEmail(String email);
    Optional<User> findOptionalUserByEmail(String email);
}

