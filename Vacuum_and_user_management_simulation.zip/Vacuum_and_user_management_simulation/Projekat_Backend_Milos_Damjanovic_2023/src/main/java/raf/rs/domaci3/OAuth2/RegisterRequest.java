package raf.rs.domaci3.OAuth2;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class RegisterRequest {
    private String username;
    private String password;
    private String firstName;
    private String lastName;

    private Boolean can_create_users;
    private Boolean can_read_users;
    private Boolean can_update_users;
    private Boolean can_delete_users;
    private Boolean can_search_vacuum;
    private Boolean can_start_vacuum;
    private Boolean can_stop_vacuum;
    private Boolean can_discharge_vacuum;
    private Boolean can_add_vacuum;
    private Boolean can_remove_vacuums;
}
