package raf.rs.domaci3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Domaci3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
