export interface User{
  id: number,
  firstName: string,
  lastName: string,
  email: string,
  password: string,
  can_read_users: boolean,
  can_create_users: boolean,
  can_update_users: boolean,
  can_delete_users: boolean,

  can_search_vacuum: boolean,
  can_start_vacuum: boolean,
  can_stop_vacuum: boolean,
  can_discharge_vacuum: boolean,
  can_add_vacuum: boolean,
  can_remove_vacuums: boolean
}

export interface LoginRequest{
  email: string,
  password: string
}

export interface Vacuum{
  id: number,
  name: string,
  status: string,
  date: string,
  user: User,
  active: boolean,
  processing: boolean
}

export interface ErrorMessage{
  id: number,
  vacuumId: number,
  userId: number,
  date: string,
  operation: string,
  message: string
}
