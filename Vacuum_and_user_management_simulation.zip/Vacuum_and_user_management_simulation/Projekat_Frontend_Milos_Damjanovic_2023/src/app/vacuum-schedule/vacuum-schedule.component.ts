import {Component, OnInit} from '@angular/core';
import {User, Vacuum} from "../model";
import {FormBuilder, FormGroup} from "@angular/forms";
import {DatePipe} from "@angular/common";
import {ApiService} from "../services/apiService";
import {ActivatedRoute, Router} from "@angular/router";

@Component({
  selector: 'app-vacuum-schedule',
  templateUrl: './vacuum-schedule.component.html',
  styleUrl: './vacuum-schedule.component.css'
})
export class VacuumScheduleComponent implements OnInit {

  vacuum: Vacuum;
  user: User;
  scheduledStartVacuumForm: FormGroup;
  scheduledStopVacuumForm: FormGroup;
  scheduledDischargeVacuumForm: FormGroup;

  pipe = new DatePipe('en-US');

  constructor(private router: Router, private route: ActivatedRoute, private formBuilder: FormBuilder, private apiService: ApiService) {

    this.user = {
      id: 0,
      firstName: '',
      lastName: '',
      email: '',
      password: '',
      can_read_users: false,
      can_create_users: false,
      can_update_users: false,
      can_delete_users: false,
      can_search_vacuum: false,
      can_start_vacuum: false,
      can_stop_vacuum: false,
      can_discharge_vacuum: false,
      can_add_vacuum: false,
      can_remove_vacuums: false
    };

    this.vacuum = {
      id: 0,
      name: '',
      status: '',
      date: '',
      user: this.user,
      active: false,
      processing: false
    };

    this.scheduledStartVacuumForm = this.formBuilder.group({
      date: Date
    });

    this.scheduledStopVacuumForm = this.formBuilder.group({
      date: Date
    });

    this.scheduledDischargeVacuumForm = this.formBuilder.group({
      date: Date
    });
  }

  ngOnInit(): void {
    this.getVacuumById()
  }

  getVacuumById(){
    this.apiService.getVacuumById(parseInt(<string>this.route.snapshot.paramMap.get('id')))
      .subscribe(result => {
        this.vacuum = result;
        console.log(result)
      })
  }

  scheduledStartVacuum() {
    console.log(this.scheduledStartVacuumForm.get('date')?.value)
    let date = this.scheduledStartVacuumForm.get('date')?.value;
    let stringDate = this.pipe.transform(date, "dd.MM.yyyy HH:mm");
    if(stringDate === null){
      alert("Date cannot be left empty");
      return;
    }else{

    }
    this.apiService.scheduledStart(this.vacuum.id, stringDate).subscribe( result => {
      alert("Vacuum scheduled");
      this.router.navigate(['/searchVacuum']);
    })
  }

  scheduledStopVacuum() {
    let date = this.scheduledStopVacuumForm.get('date')?.value;
    let stringDate = this.pipe.transform(date, "dd.MM.yyyy HH:mm");
    if(stringDate === null){
      alert("Date cannot be left empty");
      return;
    }
    this.apiService.scheduledStop(this.vacuum.id, stringDate).subscribe( result => {
      alert("Vacuum scheduled");
      this.router.navigate(['/searchVacuum']);
    })
  }

  scheduledDischargeVacuum() {
    let date = this.scheduledDischargeVacuumForm.get('date')?.value;
    let stringDate = this.pipe.transform(date, "dd.MM.yyyy HH:mm");
    if(stringDate === null){
      alert("Date cannot be left empty");
      return;
    }
    this.apiService.scheduledDischarge(this.vacuum.id, stringDate).subscribe( result => {
      alert("Vacuum scheduled");
      this.router.navigate(['/searchVacuum']);
    })
  }

  checkPermission(p: string){
    let token = localStorage.getItem("token");

    if(token == null) return false;
    if(localStorage.getItem(p) == null) return false;
    // @ts-ignore
    var variable= /^true$/i.test(localStorage.getItem(p))
    return variable;
  }
}
