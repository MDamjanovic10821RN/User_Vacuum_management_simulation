import { Component } from '@angular/core';
import {ApiService} from "../services/apiService";
import {FormBuilder, FormGroup} from "@angular/forms";
import {Router} from "@angular/router";
//import * as jwt_decode from "jwt-decode"; //biblioteka sa: npm install jwt-decode
import {JwtHelperService, JwtModule} from "@auth0/angular-jwt";

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {

  // loginForm: FormGroup;
   jwtDecoder: JwtHelperService;

   email_input: string;
   password_input: string;

  constructor(private apiService: ApiService, private formBuilder: FormBuilder, private router: Router) {

    this.jwtDecoder = new JwtHelperService();

    this.email_input = '';
    this.password_input = '';

    // this.loginForm = this.formBuilder.group({
    //   email_input: '',
    //   password_input: ''
    // });

  }

  login(){
    //console.log("-------------------yeah,yeah... whatever. you may proceed")
    localStorage.clear();
    this.apiService.login(this.email_input, this.password_input
    ).subscribe({
        next: res => {
          localStorage.setItem('token', res.token)

          const decodedToken = this.jwtDecoder.decodeToken(res.token)
          console.log(decodedToken);
          localStorage.setItem('can_create_users', decodedToken.c)
          localStorage.setItem('can_read_users', decodedToken.r)
          localStorage.setItem('can_update_users', decodedToken.u)
          localStorage.setItem('can_delete_users', decodedToken.d)

          localStorage.setItem('can_search_vacuum', decodedToken.search)
          localStorage.setItem('can_start_vacuum', decodedToken.start)
          localStorage.setItem('can_stop_vacuum', decodedToken.stop)
          localStorage.setItem('can_discharge_vacuum', decodedToken.discharge)
          localStorage.setItem('can_add_vacuum', decodedToken.add)
          localStorage.setItem('can_remove_vacuums', decodedToken.remove)

          this.router.navigate(["/table"])

        },
        error: err => {
          alert(`Error ${err.status}. Incorrect credentials.`)
        }
      }
    )
  }
}
