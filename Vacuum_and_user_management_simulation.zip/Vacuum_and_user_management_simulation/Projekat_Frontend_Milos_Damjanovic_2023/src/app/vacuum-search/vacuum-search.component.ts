import {Component, OnInit} from '@angular/core';
import {User, Vacuum} from "../model";
import {FormBuilder, FormGroup} from "@angular/forms";
import {ApiService} from "../services/apiService";

@Component({
  selector: 'app-vacuum-search',
  templateUrl: './vacuum-search.component.html',
  styleUrl: './vacuum-search.component.css'
})
export class VacuumSearchComponent implements OnInit{

  vacuums: Vacuum[];
  searchVacuumsForm: FormGroup;

  constructor(private formBuilder: FormBuilder, private apiService: ApiService) {
    this.searchVacuumsForm = this.formBuilder.group({
      vacuumName: '',
      dateFrom: '',
      dateTo: '',
    });
    this.vacuums = [] as Vacuum[];
  }

  ngOnInit(): void {
    this.getVacuumsForUser();
  }

  getVacuumsForUser(){
    this.apiService.getVacuumsForUser()
      .subscribe(result => {
        this.vacuums = result;
      });
  }

   searchVacuums() {

    let statusArray = []

    let elements = (<HTMLInputElement[]><any>document.getElementsByClassName("form-check-input"));

    for (let i = 0; i < elements.length; i++) {
      if (elements[i].type == "checkbox") {
        if (elements[i].checked){
          let value = elements[i].value;
          if(value === 'STOPPED') {
            statusArray.push("STOPPED");
          }
          if(value === 'RUNNING'){
            statusArray.push("RUNNING");
          }
          if(value === 'DISCHARGING'){
            statusArray.push("DISCHARGING");
          }
        }
      }
    }

    this.apiService.searchVacuums(
      this.searchVacuumsForm.get('vacuumName')?.value,
      statusArray.length === 0 ? null : statusArray,
      this.searchVacuumsForm.get('dateFrom')?.value,
      this.searchVacuumsForm.get('dateTo')?.value
    ).subscribe( {
      next: value => {
        this.vacuums = value;
      },
      error: err => {
        alert(err);
      }
    });
  }

  removeVacuum(id: number) {
      this.apiService.removeVacuum(id)
        .subscribe(result=> {
          alert(`Vacuum (${id}) removed.`)
          this.getVacuumsForUser();
      });
    }

  startVacuum(id: number) {
    this.apiService.startVacuum(id)
      .subscribe({
        next: value => {
          console.log(value)
        },
        error: err => {
          alert(err?.body);
        }
      });
    setTimeout(function() {
      window.location.reload()
    }, 15001);
  }

  stopVacuum(id: number) {
    this.apiService.stopVacuum(id)
      .subscribe({
        next: value => {
          console.log(value)
        },
        error: err => {
          alert(err?.body);
        }
      });
    setTimeout(function() {
      window.location.reload()
    }, 15001);
  }

  dischargeVacuum(id: number) {

    setTimeout(function() {
      window.location.reload()
    }, 15001);

    this.apiService.dischargeVacuum(id)
      .subscribe({
        next: value => {
          console.log(value);
        },
        error: err => {
          alert(err?.body);
        }
      });
    // setTimeout(function() {
    //   window.location.reload()
    // }, 15001);
    setTimeout(function() {
      window.location.reload() //TODO: nece ponovo posle 30sec!!!
    }, 30001);
  }

  clearForm() {
    this.searchVacuumsForm.reset();
    let elements = (<HTMLInputElement[]><any>document.getElementsByClassName("form-check-input"));
    for (let i = 0; i < elements.length; i++) {
      elements[i].checked = false;
    }
  }

  checkPermission(p: string){
    let token = localStorage.getItem("token");

    if(token == null) return false;
    if(localStorage.getItem(p) == null) return false;
    // @ts-ignore
    var variable= /^true$/i.test(localStorage.getItem(p))
    return variable;
  }

  isStopped(status: string){
    if(status === 'STOPPED') return true;
    else return false;
  }

}
