import {Injectable} from "@angular/core";
import {Observable} from "rxjs";
import {HttpClient, HttpHeaders, HttpResponse} from "@angular/common/http";
import {LoginRequest} from "../model";

@Injectable({
  providedIn: 'root'
})
export class ApiService {

  private headers = new HttpHeaders({
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${localStorage.getItem("token")}`
  })

  constructor(private httpClient: HttpClient) { }

  //--------------------------------------------------------------------------------------------------------------------
  getAllUsers():Observable<any>{
    console.log("Apiservice; getallusers: token from localstorage: "+localStorage.getItem("token")+"/n header: "+this.headers);
    this.refreshHeaders();
    return this.httpClient.get('http://localhost:8080/users/all', {headers:this.headers})
  }

  deleteUser(id: string):Observable<any>{
    this.refreshHeaders();
    return this.httpClient.delete(`http://localhost:8080/users/delete/${id}`, {headers:this.headers})
  }

  updateUser(id: string, firstName: string, lastName: string, email: string, password: string, can_create_users: boolean, can_read_users: boolean, can_update_users: boolean, can_delete_users: boolean, can_search_vacuum: boolean, can_start_vacuum: boolean, can_stop_vacuum: boolean, can_discharge_vacuum: boolean, can_add_vacuum: boolean, can_remove_vacuums: boolean):Observable<any>{
    this.refreshHeaders();
    return this.httpClient.put<HttpResponse<any>>(`http://localhost:8080/users/update`,
      {id: id, email: email, firstName: firstName, lastName: lastName, password: password, can_create_users: can_create_users, can_read_users: can_read_users, can_update_users: can_update_users, can_delete_users: can_delete_users,
        can_search_vacuum: can_search_vacuum, can_start_vacuum: can_add_vacuum, can_stop_vacuum: can_stop_vacuum, can_discharge_vacuum: can_discharge_vacuum, can_add_vacuum: can_add_vacuum, can_remove_vacuums: can_remove_vacuums }, {headers:this.headers})
  }

  createUser(firstName: string, lastName: string, email: string, password: string, can_create_users: boolean, can_read_users: boolean, can_update_users: boolean, can_delete_users: boolean, can_search_vacuum: boolean, can_start_vacuum: boolean, can_stop_vacuum: boolean, can_discharge_vacuum: boolean, can_add_vacuum: boolean, can_remove_vacuums: boolean):Observable<any>{
    this.refreshHeaders();
    return this.httpClient.post<HttpResponse<any>>(`http://localhost:8080/users/new`,
      {email: email, firstName: firstName, lastName: lastName, password: password, can_create_users: can_create_users, can_read_users: can_read_users, can_update_users: can_update_users, can_delete_users: can_delete_users,
        can_search_vacuum: can_search_vacuum, can_start_vacuum: can_add_vacuum, can_stop_vacuum: can_stop_vacuum, can_discharge_vacuum: can_discharge_vacuum, can_add_vacuum: can_add_vacuum, can_remove_vacuums: can_remove_vacuums }, {headers:this.headers})
  }

  getUserById(id: number): Observable<any> {
    this.refreshHeaders();
    return this.httpClient.get(`http://localhost:8080/users/${id}`, {headers: this.headers});
  }

  //--------------------------------------------------------------------------------------------------------------------

  login(email: string, password : string):Observable<any>{
    return this.httpClient.post<LoginRequest>('http://localhost:8080/auth/authenticate',{username:email, password:password})
  }

  refreshHeaders(){
    this.headers = new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${localStorage.getItem("token")}`
    })
  }
  //--------------------------------------------------------------------------------------------------------------------

  addVacuum(name: string): Observable<any> {
    this.refreshHeaders();
    return this.httpClient.post<HttpResponse<any>>('http://localhost:8080/vacuums/new', name, {headers: this.headers});
  }

  removeVacuum(id: number):Observable<any>{
    this.refreshHeaders();
    return this.httpClient.delete(`http://localhost:8080/vacuums/delete/${id}`, {headers:this.headers})
  }

  getVacuumsForUser(): Observable<any>{
    this.refreshHeaders();
    return this.httpClient.get<HttpResponse<any>>('http://localhost:8080/vacuums/byUser', {headers: this.headers})
  }

  getVacuumById(id: number): Observable<any> {
    return this.httpClient.get(`http://localhost:8080/vacuums/get/${id}`, {headers: this.headers});
  }

  searchVacuums(name: string | null, status: string[] | null, dateFrom: string | null, dateTo: string | null): Observable<any>{
    this.refreshHeaders();
    return this.httpClient.put<HttpResponse<any>>('http://localhost:8080/vacuums/search', {name: name, status: status, dateFrom: dateFrom, dateTo: dateTo}, {headers: this.headers})
  }
  //--------------------------------------------------------------------------------------------------------------------

  startVacuum(id: number): Observable<any> {
    this.refreshHeaders();
    return this.httpClient.get(`http://localhost:8080/vacuums/start/${id}`, {headers: this.headers})
  }

  stopVacuum(id: number): Observable<any> {
    this.refreshHeaders();
    return this.httpClient.get(`http://localhost:8080/vacuums/stop/${id}`, {headers: this.headers})
  }

  dischargeVacuum(id: number): Observable<any> {
    this.refreshHeaders();
    return this.httpClient.get(`http://localhost:8080/vacuums/discharge/${id}`, {headers: this.headers})
  }

  scheduledStart(id: number, date: string) {
    return this.httpClient.get(`http://localhost:8080/vacuums/scheduledStart/${id}?date=${date}`, {headers: this.headers})
  }

  scheduledStop(id: number, date: string) {
    return this.httpClient.get(`http://localhost:8080/vacuums/scheduledStop/${id}?date=${date}`, {headers: this.headers})
  }

  scheduledDischarge(id: number, date: string) {
    return this.httpClient.get(`http://localhost:8080/vacuums/scheduledDischarge/${id}?date=${date}`, {headers: this.headers})
  }
  //--------------------------------------------------------------------------------------------------------------------

  getAllErrors(): Observable<any> {
    return this.httpClient.get(`http://localhost:8080/errors/get`, {headers: this.headers})
  }

}
