import { Component } from '@angular/core';
import {FormBuilder, FormGroup} from "@angular/forms";
import {User} from "../model";
import {ApiService} from "../services/apiService";
import {ActivatedRoute, Router} from "@angular/router";

@Component({
  selector: 'app-user-create',
  templateUrl: './user-create.component.html',
  styleUrl: './user-create.component.css'
})
export class UserCreateComponent {

  createUserForm: FormGroup;

  constructor(private apiService: ApiService, private formBuilder: FormBuilder, private router: Router, private route: ActivatedRoute, ) {

    this.createUserForm = this.formBuilder.group({
      firstName: '',
      lastName: '',
      email: '',
      password: '',
      can_create_users: false,
      can_read_users: false,
      can_update_users: false,
      can_delete_users: false,
      can_search_vacuum: false,
      can_start_vacuum: false,
      can_stop_vacuum: false,
      can_discharge_vacuum: false,
      can_add_vacuum: false,
      can_remove_vacuums: false
    });

  }

  createUser(){

    let elements = (<HTMLInputElement[]><any>document.getElementsByClassName("form-check-input"));
    console.log(elements[4].checked+" "+elements[5].checked+" "+elements[6].checked+" "+elements[7].checked+" "+elements[8].checked+" "+elements[9].checked);
    this.apiService.createUser(
      this.createUserForm.get('firstName')?.value,
      this.createUserForm.get('lastName')?.value,
      this.createUserForm.get('email')?.value,
      this.createUserForm.get('password')?.value,
      elements[0].checked,
      elements[1].checked,
      elements[2].checked,
      elements[3].checked,
      elements[4].checked,
      elements[5].checked,
      elements[6].checked,
      elements[7].checked,
      elements[8].checked,
      elements[9].checked
    ).subscribe(result => {
      alert("User created");
      this.router.navigate(['/table']);
    });
  }

  checkPermission(p: string){
    let token = localStorage.getItem("token");

    if(token == null) return false;
    if(localStorage.getItem(p) == null) return false;
    // @ts-ignore
    var variable= /^true$/i.test(localStorage.getItem(p))
    return variable;
  }

}
