import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VacuumCreateComponent } from './vacuum-create.component';

describe('VacuumCreateComponent', () => {
  let component: VacuumCreateComponent;
  let fixture: ComponentFixture<VacuumCreateComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [VacuumCreateComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(VacuumCreateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
