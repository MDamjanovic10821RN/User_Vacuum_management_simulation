import { Component } from '@angular/core';
import {FormBuilder, FormGroup} from "@angular/forms";
import {ApiService} from "../services/apiService";
import {Router} from "@angular/router";

@Component({
  selector: 'app-vacuum-create',
  templateUrl: './vacuum-create.component.html',
  styleUrl: './vacuum-create.component.css'
})
export class VacuumCreateComponent {

  newVacuumForm: FormGroup;

  constructor(private router: Router, private formBuilder: FormBuilder, private apiService: ApiService ) {
    this.newVacuumForm = this.formBuilder.group({
      vacuumName: ''
    });
  }

  addVacuum(){
    this.apiService.addVacuum(
      this.newVacuumForm.get('vacuumName')?.value
    ).subscribe( {
      next: res => {
        alert("Vacuum created successfully.");
        this.router.navigate(['/searchVacuum']);
      },
      error: err => {
        alert(err);
      }
    });
  }
}
