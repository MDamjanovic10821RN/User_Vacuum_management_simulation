import {ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree} from "@angular/router";
import {Observable} from "rxjs";
import {Injectable} from "@angular/core";

@Injectable({
  providedIn: 'root'
})
export class VSearchGuard implements CanActivate {
  constructor(private router: Router) {
  }
  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {

    if(localStorage.getItem("can_search_vacuum")=='true')
      return true;

    alert("Access denied. You do not have sufficient privileges.");
    return false;

  }
}
@Injectable({
  providedIn: 'root'
})
export class VStartGuard implements CanActivate {
  constructor(private router: Router) {
  }
  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {

    if(localStorage.getItem("can_start_vacuum")=='true')
      return true;

    alert("Access denied. You do not have sufficient privileges.");
    return false;

  }
}
@Injectable({
  providedIn: 'root'
})
export class VStopGuard implements CanActivate {
  constructor(private router: Router) {
  }
  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {

    if(localStorage.getItem("can_stop_vacuum")=='true')
      return true;

    alert("Access denied. You do not have sufficient privileges.");
    return false;

  }
}
@Injectable({
  providedIn: 'root'
})
export class VDischargeGuard implements CanActivate {
  constructor(private router: Router) {
  }
  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {

    if(localStorage.getItem("can_discharge_vacuum")=='true')
      return true;

    alert("Access denied. You do not have sufficient privileges.");
    return false;

  }
}
@Injectable({
  providedIn: 'root'
})
export class VAddGuard implements CanActivate {
  constructor(private router: Router) {
  }
  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {

    if(localStorage.getItem("can_add_vacuum")=='true')
      return true;

    alert("Access denied. You do not have sufficient privileges.");
    return false;

  }
}
@Injectable({
  providedIn: 'root'
})
export class VRemoveGuard implements CanActivate {
  constructor(private router: Router) {
  }
  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {

    if(localStorage.getItem("can_remove_vacuum")=='true')
      return true;

    alert("Access denied. You do not have sufficient privileges.");
    return false;

  }
}
@Injectable({
  providedIn: 'root'
})
export class VScheduleGuard implements CanActivate {
  constructor(private router: Router) {
  }
  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {

    if(localStorage.getItem("can_start_vacuum")=='true' || localStorage.getItem("can_stop_vacuum")=='true' || localStorage.getItem("can_discharge_vacuum")=='true')
      return true;

    alert("Access denied. You do not have sufficient privileges.");
    return false;

  }
}
