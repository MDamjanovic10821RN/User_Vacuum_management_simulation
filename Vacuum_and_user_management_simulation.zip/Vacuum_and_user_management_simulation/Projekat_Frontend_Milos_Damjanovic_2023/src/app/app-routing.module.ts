import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {LoginComponent} from "./login/login.component";
import {UserTableComponent} from "./user-table/user-table.component";
import {UserCreateComponent} from "./user-create/user-create.component";
import {UserUpdateComponent} from "./user-update/user-update.component";

import {VacuumCreateComponent} from "./vacuum-create/vacuum-create.component";
import {VacuumHistoryComponent} from "./vacuum-history/vacuum-history.component";
import {VacuumSearchComponent} from "./vacuum-search/vacuum-search.component";
import {VacuumScheduleComponent} from "./vacuum-schedule/vacuum-schedule.component";

import {ReadGuard} from "./guards/readGuard";
import {CreateGuard} from "./guards/createGuard";
import {UpdateGuard} from "./guards/updateGuard";

import {VSearchGuard} from "./guards/vacuumGuard";
import {VStartGuard} from "./guards/vacuumGuard";
import {VStopGuard} from "./guards/vacuumGuard";
import {VDischargeGuard} from "./guards/vacuumGuard";
import {VAddGuard} from "./guards/vacuumGuard";
import {VScheduleGuard} from "./guards/vacuumGuard";

const routes: Routes = [
  {
    path: "",
    component: LoginComponent
  },
  {
    path: "table",
    component: UserTableComponent,
    canActivate: [ReadGuard]
  },
  {
    path: "newUser",
    component: UserCreateComponent,
    canActivate: [CreateGuard]
  },
  {
    path: "editUser/:id",
    component: UserUpdateComponent,
    canActivate: [UpdateGuard]
  },
  {
    path: "newVacuum",
    component: VacuumCreateComponent,
    canActivate: [VAddGuard]
  },
  {
    path: "history",
    component: VacuumHistoryComponent,
    canActivate: [VAddGuard]
  },
  {
    path: "searchVacuum",
    component: VacuumSearchComponent,
    canActivate: [VSearchGuard]
  },
  {
    path: "scheduleVacuum/:id",
    component: VacuumScheduleComponent,
    canActivate: [VScheduleGuard]
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
