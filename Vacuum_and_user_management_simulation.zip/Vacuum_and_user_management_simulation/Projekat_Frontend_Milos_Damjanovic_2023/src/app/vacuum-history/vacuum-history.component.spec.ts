import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VacuumHistoryComponent } from './vacuum-history.component';

describe('VacuumHistoryComponent', () => {
  let component: VacuumHistoryComponent;
  let fixture: ComponentFixture<VacuumHistoryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [VacuumHistoryComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(VacuumHistoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
