import { Component } from '@angular/core';
import {ApiService} from "../services/apiService";
import {ErrorMessage, User} from "../model";

@Component({
  selector: 'app-vacuum-history',
  templateUrl: './vacuum-history.component.html',
  styleUrl: './vacuum-history.component.css'
})
export class VacuumHistoryComponent {
  errors: ErrorMessage[];

  constructor(private apiService: ApiService) {
    this.errors = [] as ErrorMessage[];
  }

  ngOnInit(): void {
    this.getAllErrors();
  }

  getAllErrors(){
    this.apiService.getAllErrors()
      .subscribe(result => {
        this.errors = result;
        console.log(result);
      })
  }

}
