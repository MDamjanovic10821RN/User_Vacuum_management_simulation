import {Component, OnInit} from '@angular/core';
import {FormBuilder, FormGroup} from "@angular/forms";
import {User} from "../model";
import {ApiService} from "../services/apiService";
import {ActivatedRoute, Router} from "@angular/router";

@Component({
  selector: 'app-user-update',
  templateUrl: './user-update.component.html',
  styleUrl: './user-update.component.css'
})
export class UserUpdateComponent implements OnInit {

  editUserForm: FormGroup;
  user: User


  constructor(private apiService: ApiService, private formBuilder: FormBuilder, private router: Router, private route: ActivatedRoute, ) {

    this.user = {
      id: 0,
      firstName: '',
      lastName: '',
      email: '',
      password: '',
      can_read_users: false,
      can_create_users: false,
      can_update_users: false,
      can_delete_users: false,
      can_search_vacuum: false,
      can_start_vacuum: false,
      can_stop_vacuum: false,
      can_discharge_vacuum: false,
      can_add_vacuum: false,
      can_remove_vacuums: false
    };

    this.editUserForm = this.formBuilder.group({
      firstName: '',
      lastName: '',
      email: '',
      can_create_users: this.user.can_create_users,
      can_read_users: this.user.can_read_users,
      can_update_users: this.user.can_update_users,
      can_delete_users: this.user.can_delete_users,
      can_search_vacuum: this.user.can_search_vacuum,
      can_start_vacuum: this.user.can_start_vacuum,
      can_stop_vacuum: this.user.can_stop_vacuum,
      can_discharge_vacuum: this.user.can_discharge_vacuum,
      can_add_vacuum: this.user.can_add_vacuum,
      can_remove_vacuums: this.user.can_remove_vacuums
    });
    this.getById();
    console.log(this.user);
  }

  ngOnInit(): void {
    this.getById()
  }

  updateUser(){

    let elements = (<HTMLInputElement[]><any>document.getElementsByClassName("form-check-input"));

    this.apiService.updateUser(
      <string>this.route.snapshot.paramMap.get('id'),
      this.editUserForm.get('firstName')?.value,
      this.editUserForm.get('lastName')?.value,
      this.editUserForm.get('email')?.value,
      this.user.password,
      elements[0].checked,
      elements[1].checked,
      elements[2].checked,
      elements[3].checked,
      elements[4].checked,
      elements[5].checked,
      elements[6].checked,
      elements[7].checked,
      elements[8].checked,
      elements[9].checked
    ).subscribe(result => {
      alert("User updated");
      this.router.navigate(['/table']);
    });


  }

  getById(){
    this.apiService.getUserById(parseInt(<string>this.route.snapshot.paramMap.get('id')))
      .subscribe(result => {
        this.user = result;
        //console.log("result is: "+ result);
        //return result;
        //this.permissions = result.permissions
        console.log("LOGGING: "+ this.user.can_search_vacuum);

        this.editUserForm.setValue({
          firstName: this.user.firstName,
          lastName: this.user.lastName,
          email: this.user.email,
          can_create_users: this.user.can_create_users,
          can_read_users: this.user.can_read_users,
          can_update_users: this.user.can_update_users,
          can_delete_users: this.user.can_delete_users,
          can_search_vacuum: this.user.can_search_vacuum,
          can_start_vacuum: this.user.can_start_vacuum,
          can_stop_vacuum: this.user.can_stop_vacuum,
          can_discharge_vacuum: this.user.can_discharge_vacuum,
          can_add_vacuum: this.user.can_add_vacuum,
          can_remove_vacuums: this.user.can_remove_vacuums
        });
      })
  }

  check(permission: string){ //za prikazivanje stanja pre update-a

    if(permission === 'can_create_users'){
      return this.user.can_create_users;
    }else if(permission == 'can_read_users'){
      return this.user.can_read_users;
    }else if(permission == 'can_update_users'){
      return this.user.can_update_users;
    }else if(permission == 'can_delete_users'){
      return this.user.can_delete_users;
    }else{
      return false;
    }

  }

  checkPermission(p: string){
    let token = localStorage.getItem("token");

    if(token == null) return false;
    if(localStorage.getItem(p) == null) return false;
    // @ts-ignore
    var variable= /^true$/i.test(localStorage.getItem(p))
    return variable;
  }

}
