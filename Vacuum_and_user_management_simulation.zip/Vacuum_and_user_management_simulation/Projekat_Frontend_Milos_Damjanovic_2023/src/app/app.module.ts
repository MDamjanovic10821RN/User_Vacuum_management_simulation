import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http'

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { UserCreateComponent } from './user-create/user-create.component';
import { UserUpdateComponent } from './user-update/user-update.component';
import { UserTableComponent } from './user-table/user-table.component';
import {FormsModule, ReactiveFormsModule} from "@angular/forms";
import { VacuumCreateComponent } from './vacuum-create/vacuum-create.component';
import { VacuumSearchComponent } from './vacuum-search/vacuum-search.component';
import { VacuumHistoryComponent } from './vacuum-history/vacuum-history.component';
import { VacuumScheduleComponent } from './vacuum-schedule/vacuum-schedule.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    UserCreateComponent,
    UserUpdateComponent,
    UserTableComponent,
    VacuumCreateComponent,
    VacuumSearchComponent,
    VacuumHistoryComponent,
    VacuumScheduleComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
