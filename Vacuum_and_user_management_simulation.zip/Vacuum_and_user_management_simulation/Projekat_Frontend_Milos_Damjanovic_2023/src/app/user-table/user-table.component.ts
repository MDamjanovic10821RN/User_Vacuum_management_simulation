import { Component } from '@angular/core';
import {User} from "../model";
import {ApiService} from "../services/apiService";
import {Router} from "@angular/router";

@Component({
  selector: 'app-user-table',
  templateUrl: './user-table.component.html',
  styleUrl: './user-table.component.css'
})
export class UserTableComponent {

  users: User[];

  constructor(private apiService: ApiService , private router: Router) {
    this.users = [] as User[];
  }

  ngOnInit(): void {
    this.getAllUsers()
  }

  getAllUsers(){
    this.apiService.getAllUsers()
      .subscribe(result => {
        this.users = result;
      })
  }

  deleteUser(id: number){
    this.apiService.deleteUser(String(id))
      .subscribe(result=> {
        alert(`User (${id}) deleted.`)
        this.getAllUsers()
      });
  }

  checkPermission(p: string){
    let token = localStorage.getItem("token");

    if(token == null) return false;
    if(localStorage.getItem(p) == null) return false;
    // @ts-ignore
    var variable= /^true$/i.test(localStorage.getItem(p))
    return variable;
  }

}
